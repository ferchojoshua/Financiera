-- Sistema de Préstamos Database Backup
-- Fecha: 2025-06-05 18:33:53

DROP TABLE IF EXISTS `accounting_entries`;
CREATE TABLE `accounting_entries` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `entry_date` date NOT NULL,
  `description` text NOT NULL,
  `entry_type` enum('ingreso','gasto','ajuste') NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `reference` varchar(191) DEFAULT NULL,
  `category` varchar(100) NOT NULL,
  `subcategory` varchar(100) DEFAULT NULL,
  `credit_id` bigint(20) unsigned DEFAULT NULL,
  `loan_application_id` bigint(20) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `accounting_account` varchar(50) DEFAULT NULL,
  `created_by` int(10) unsigned NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'active',
  `notes` text DEFAULT NULL,
  `attachment_path` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `agent_has_supervisor`;
CREATE TABLE `agent_has_supervisor` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_user_agent` int(10) unsigned NOT NULL,
  `id_supervisor` int(10) unsigned NOT NULL,
  `base` double(8,2) NOT NULL DEFAULT 0.00,
  `id_wallet` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `agent_has_supervisor_id_user_agent_foreign` (`id_user_agent`),
  KEY `agent_has_supervisor_id_supervisor_foreign` (`id_supervisor`),
  KEY `agent_has_supervisor_id_wallet_foreign` (`id_wallet`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `agent_has_supervisor` VALUES
('1', '1', '4', '5000', '1', NULL, NULL);

DROP TABLE IF EXISTS `audit`;
CREATE TABLE `audit` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_user` int(11) DEFAULT NULL,
  `data` text DEFAULT NULL,
  `action` varchar(50) DEFAULT NULL,
  `device` text DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `audit` VALUES
('1', NULL, NULL, 'view', NULL, NULL, '2025-06-03 18:59:30', '2025-06-03 18:59:30'),
('2', NULL, NULL, 'view', NULL, NULL, '2025-06-03 21:00:33', '2025-06-03 21:00:33'),
('3', NULL, NULL, 'view', NULL, NULL, '2025-06-03 21:01:33', '2025-06-03 21:01:33'),
('4', NULL, NULL, 'view', NULL, NULL, '2025-06-03 21:03:11', '2025-06-03 21:03:11'),
('5', NULL, NULL, 'view', NULL, NULL, '2025-06-03 21:04:36', '2025-06-03 21:04:36'),
('6', NULL, NULL, 'view', NULL, NULL, '2025-06-03 21:11:38', '2025-06-03 21:11:38'),
('7', NULL, NULL, 'view', NULL, NULL, '2025-06-03 21:12:11', '2025-06-03 21:12:11');

DROP TABLE IF EXISTS `bills`;
CREATE TABLE `bills` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `description` text DEFAULT NULL,
  `id_agent` int(11) DEFAULT NULL,
  `amount` double(8,2) DEFAULT 0.00,
  `type` varchar(191) DEFAULT NULL,
  `id_wallet` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `blacklists`;
CREATE TABLE `blacklists` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `dni` varchar(100) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `reason` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `branches`;
CREATE TABLE `branches` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `code` varchar(50) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `manager_id` bigint(20) unsigned DEFAULT NULL,
  `country_id` bigint(20) unsigned DEFAULT NULL,
  `status` varchar(255) DEFAULT 'active',
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `branches_code_unique` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `branches` VALUES
('1', 'Sucursal Principal de Prueba', 'SUC-001', NULL, NULL, NULL, NULL, NULL, NULL, 'active', NULL, NULL, '2025-06-03 18:32:52', '2025-06-03 18:32:52');

DROP TABLE IF EXISTS `client_records`;
CREATE TABLE `client_records` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `client_id` bigint(20) unsigned NOT NULL,
  `record_type` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `record_status` varchar(50) DEFAULT NULL,
  `record_date` date NOT NULL,
  `created_by` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_client_record_type` (`client_id`,`record_type`),
  KEY `idx_record_date` (`record_date`),
  CONSTRAINT `fk_client_records_client` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `client_records` VALUES
('1', '1', 'general_note', 'Cliente de prueba creado manualmente para verificar el sistema.', 'active', '2025-06-05', '1', '2025-06-05 01:30:38', '2025-06-05 01:30:38');

DROP TABLE IF EXISTS `client_types`;
CREATE TABLE `client_types` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `code` varchar(50) NOT NULL,
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `client_types_code_unique` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `client_types` VALUES
('1', 'Persona Natural', 'NATURAL', 'Cliente individual', '1', '2025-06-03 18:32:52', '2025-06-03 18:32:52'),
('2', 'Persona Juridica', 'JURIDICA', 'Empresas legalmente constituidas', '1', '2025-06-03 18:32:52', '2025-06-03 18:32:52'),
('3', 'Microempresa', 'MICRO', 'Peque├▒os negocios', '1', '2025-06-03 18:32:52', '2025-06-03 18:32:52'),
('4', 'PYME', 'PYME', 'Peque├▒a y Mediana Empresa', '1', '2025-06-03 18:32:52', '2025-06-03 18:32:52');

DROP TABLE IF EXISTS `clients`;
CREATE TABLE `clients` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `nit` varchar(20) DEFAULT NULL,
  `dui` varchar(20) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `country` varchar(100) DEFAULT 'El Salvador',
  `birthdate` date DEFAULT NULL,
  `business_name` varchar(255) DEFAULT NULL,
  `tax_id` varchar(20) DEFAULT NULL,
  `business_sector` varchar(100) DEFAULT NULL,
  `economic_activity` varchar(255) DEFAULT NULL,
  `annual_revenue` decimal(15,2) DEFAULT NULL,
  `employee_count` int(11) DEFAULT NULL,
  `founding_date` date DEFAULT NULL,
  `legal_representative` varchar(255) DEFAULT NULL,
  `risk_category` varchar(50) DEFAULT NULL,
  `credit_notes` text DEFAULT NULL,
  `blacklisted` tinyint(1) NOT NULL DEFAULT 0,
  `blacklist_reason` text DEFAULT NULL,
  `assigned_agent_id` bigint(20) unsigned DEFAULT NULL,
  `credit_score` int(10) unsigned DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `idx_name_last_name` (`name`,`last_name`),
  KEY `idx_nit` (`nit`),
  KEY `idx_dui` (`dui`),
  KEY `idx_business_name` (`business_name`),
  KEY `idx_assigned_agent_id` (`assigned_agent_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Tabla de clientes separada de usuarios del sistema';

INSERT INTO `clients` VALUES
('1', 'Cliente', 'De Prueba', 'cliente@ejemplo.com', '12345678', '1234-56789-123-4', '01234567-8', 'Calle Principal #123', 'San Salvador', 'San Salvador', 'El Salvador', NULL, 'Negocio de Prueba', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'B', 'Cliente de prueba para verificar la funcionalidad del sistema.', '0', NULL, NULL, NULL, '1', '1', NULL, '2025-06-05 01:30:38', '2025-06-05 01:30:38');

DROP TABLE IF EXISTS `close_day`;
CREATE TABLE `close_day` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_agent` int(11) DEFAULT NULL,
  `id_supervisor` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `total` double(8,2) DEFAULT NULL,
  `base_before` double(8,2) DEFAULT NULL,
  `from_number` double(8,2) DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `collaterals`;
CREATE TABLE `collaterals` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `credit_id` bigint(20) unsigned DEFAULT NULL,
  `type` varchar(50) NOT NULL COMMENT 'Tipo de garantía: inmueble, vehículo, etc',
  `description` text NOT NULL COMMENT 'Descripción detallada de la garantía',
  `value` decimal(15,2) NOT NULL COMMENT 'Valor estimado de la garantía',
  `status` varchar(20) NOT NULL DEFAULT 'active' COMMENT 'Estado: active, verified, rejected',
  `document_path` varchar(255) DEFAULT NULL COMMENT 'Ruta al documento de respaldo',
  `verification_date` datetime DEFAULT NULL COMMENT 'Fecha de verificación',
  `verified_by` int(10) unsigned DEFAULT NULL COMMENT 'Usuario que verificó la garantía',
  `notes` text DEFAULT NULL COMMENT 'Notas adicionales',
  `is_pyme` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Indica si la garantía es para un préstamo PYME',
  `client_type` enum('natural','juridica') NOT NULL DEFAULT 'natural' COMMENT 'Tipo de cliente: persona natural o jurídica',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_credit_id` (`credit_id`),
  KEY `idx_verified_by` (`verified_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `company_infos`;
CREATE TABLE `company_infos` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `ruc` varchar(191) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `phone` varchar(191) DEFAULT NULL,
  `email` varchar(191) DEFAULT NULL,
  `website` varchar(191) DEFAULT NULL,
  `logo_path` varchar(191) DEFAULT NULL,
  `tax_info` text DEFAULT NULL,
  `legal_representative` varchar(191) DEFAULT NULL,
  `footer_text` text DEFAULT NULL,
  `receipt_message` text DEFAULT NULL,
  `contract_footer` text DEFAULT NULL,
  `payment_terms` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `company_infos` VALUES
('1', 'Primera FINACIERA', '12345678', 'Texaco Guadalupe 2c Al Este 1/2 al N\r\nLeón', '86595453', 'gueroldbenito@gmail.com', NULL, 'logos/iCeFFlSA3cBwGzRDAdQ6eERzySDaf1V0wrnUko5Y.jpg', NULL, 'gueroldbenito', 'Pie de Página General', 'Mensaje en Recibos', 'Pie de Página para Contratos', 'Términos de Pago', '2025-06-03 21:04:30', '2025-06-03 21:04:30');

DROP TABLE IF EXISTS `countrys`;
CREATE TABLE `countrys` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `countrys` VALUES
('1', 'Benin'),
('2', 'Ethiopia'),
('3', 'Nigeria');

DROP TABLE IF EXISTS `credit`;
CREATE TABLE `credit` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_user` bigint(20) unsigned NOT NULL,
  `client_id` bigint(20) unsigned DEFAULT NULL,
  `id_agent` bigint(20) unsigned DEFAULT NULL,
  `credit_number` varchar(255) DEFAULT NULL,
  `amount_requested` decimal(15,2) DEFAULT NULL,
  `amount_approved` decimal(15,2) DEFAULT NULL,
  `utility_rate` decimal(8,2) DEFAULT NULL,
  `first_pay` date DEFAULT NULL,
  `payment_number` int(11) DEFAULT NULL,
  `payment_type` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT 'inprogress',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `approval_date` date DEFAULT NULL,
  `disbursement_date` date DEFAULT NULL,
  `branch_id` bigint(20) unsigned DEFAULT NULL,
  `route_id` bigint(20) unsigned DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `is_overdue` tinyint(1) NOT NULL DEFAULT 0,
  `amount_neto` decimal(10,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`id`),
  KEY `credit_id_user_index` (`id_user`),
  KEY `credit_id_agent_index` (`id_agent`),
  KEY `credit_status_index` (`status`),
  KEY `fk_credit_client` (`client_id`),
  CONSTRAINT `fk_credit_client` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `db_countries`;
CREATE TABLE `db_countries` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `code` varchar(10) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `db_pending_pays`;
CREATE TABLE `db_pending_pays` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_credit` int(11) DEFAULT NULL,
  `id_user` int(11) DEFAULT NULL,
  `amount` decimal(10,2) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `list_bill`;
CREATE TABLE `list_bill` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '	',
  `name` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `list_bill` VALUES
('1', 'Gasolina'),
('2', 'Almuerzo'),
('3', 'Sueldo'),
('4', 'Sueldo Supervisor'),
('5', 'Recarga'),
('6', 'Aceite'),
('7', 'Moto'),
('8', 'Sistema'),
('9', 'Transito'),
('10', 'Arriendo'),
('11', 'Servicios'),
('12', 'Retiro de Caja'),
('13', 'Para otro Cobro'),
('14', 'Ajuste de Caja'),
('15', 'Deposito'),
('16', 'Policia');

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `migrations` VALUES
('1', '2017_12_03_000000_create_users_table', '1'),
('2', '2017_12_03_000001_create_wallet_table', '1'),
('3', '2017_12_03_000002_create_agent_has_supervisor_table', '1'),
('4', '2017_12_03_000002_create_credit_table', '1'),
('5', '2017_12_03_000003_create_agent_has_client_table', '1'),
('6', '2017_12_03_000004_create_password_resets_table', '1'),
('7', '2017_12_03_000005_create_route_table', '1'),
('8', '2017_12_03_000006_create_migrations_table', '1'),
('9', '2017_12_03_000007_create_summary_table', '1'),
('10', '2017_12_03_000008_create_countrys_table', '1'),
('11', '2017_12_03_000009_create_not_pay_table', '1'),
('12', '2017_12_03_000010_create_users_has_route_table', '1'),
('13', '2017_12_03_000011_create_payment_number_table', '1'),
('14', '2017_12_03_000012_create_close_day_table', '1'),
('15', '2017_12_03_000013_create_bills_table', '1'),
('16', '2017_12_03_000014_create_list_bill_table', '1'),
('17', '2021_04_23_024554_create_db_pending_pays_table', '1'),
('18', '2021_04_30_085511_create_pending_pays_table', '1'),
('19', '2021_05_01_151407_create_audit_table', '1'),
('20', '2021_05_30_224119_create_db_blacklists_table', '1'),
('21', '2023_05_28_000000_create_company_info_table', '1'),
('22', '2023_05_28_000001_add_role_to_users_table', '1'),
('23', '2025_05_30_000001_create_roles_table', '2');

DROP TABLE IF EXISTS `modules`;
CREATE TABLE `modules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `modules_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `modules` VALUES
('1', 'Dashboard', 'dashboard', 'Panel principal', '2025-06-03 22:37:51', '2025-06-03 22:37:51'),
('2', 'Clientes', 'clientes', 'Gesti??n de clientes', '2025-06-03 22:37:51', '2025-06-03 22:37:51'),
('3', 'Creditos', 'creditos', 'Gestion de creditos', '2025-06-03 22:37:51', '2025-06-03 23:07:36'),
('4', 'Pagos', 'pagos', 'Gesti??n de pagos', '2025-06-03 22:37:51', '2025-06-03 22:37:51'),
('5', 'Cobranzas', 'cobranzas', 'Gesti??n de cobranzas', '2025-06-03 22:37:51', '2025-06-03 22:37:51'),
('6', 'Reportes', 'reportes', 'Reportes del sistema', '2025-06-03 22:37:51', '2025-06-03 22:37:51'),
('7', 'Configuracion', 'configuracion', 'Configuracion del sistema', '2025-06-03 22:37:51', '2025-06-03 23:07:12'),
('8', 'Usuarios', 'usuarios', 'Gestion de usuarios', '2025-06-03 22:37:51', '2025-06-03 23:07:52'),
('9', 'Contabilidad', 'contabilidad', 'Gesti??n contable', '2025-06-03 22:37:51', '2025-06-03 22:37:51');

DROP TABLE IF EXISTS `not_pay`;
CREATE TABLE `not_pay` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `id_credit` int(11) NOT NULL,
  `id_user` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `not_pay` VALUES
('1', '2021-06-28 07:03:55', '3', '8');

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE `password_resets` (
  `email` varchar(191) NOT NULL,
  `token` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `payment_number`;
CREATE TABLE `payment_number` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` int(11) DEFAULT NULL,
  `id_agent` int(11) DEFAULT NULL,
  `selected` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `payment_number` VALUES
('1', '1', NULL, NULL),
('2', '2', NULL, NULL),
('3', '3', NULL, NULL),
('4', '4', NULL, NULL),
('5', '5', NULL, NULL),
('6', '6', NULL, NULL),
('7', '7', NULL, NULL),
('8', '8', NULL, NULL),
('9', '9', NULL, NULL),
('10', '10', NULL, NULL),
('11', '11', NULL, NULL),
('12', '12', NULL, NULL),
('13', '13', NULL, NULL),
('14', '14', NULL, NULL),
('15', '15', NULL, NULL),
('16', '16', NULL, NULL),
('17', '17', NULL, NULL),
('18', '18', NULL, NULL),
('19', '19', NULL, NULL),
('20', '20', NULL, NULL),
('21', '21', NULL, NULL),
('22', '22', NULL, NULL),
('23', '23', NULL, NULL),
('24', '24', NULL, NULL),
('25', '25', NULL, NULL),
('26', '26', NULL, NULL),
('27', '27', NULL, NULL),
('28', '28', NULL, NULL),
('29', '29', NULL, NULL),
('30', '30', NULL, NULL);

DROP TABLE IF EXISTS `pending_pays`;
CREATE TABLE `pending_pays` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_credit` int(11) DEFAULT NULL,
  `id_user` int(11) DEFAULT NULL,
  `amount` decimal(10,2) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `role_module_permissions`;
CREATE TABLE `role_module_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` bigint(20) unsigned NOT NULL,
  `module` varchar(100) NOT NULL,
  `module_id` int(11) NOT NULL,
  `has_access` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `role_module_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_module_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=426 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `role_module_permissions` VALUES
('1', '1', '', '2', '1', '2025-06-03 23:02:10', '2025-06-03 23:02:10'),
('2', '1', '', '5', '1', '2025-06-03 23:02:10', '2025-06-03 23:02:10'),
('3', '1', '', '7', '1', '2025-06-03 23:02:10', '2025-06-03 23:02:10'),
('4', '1', '', '9', '1', '2025-06-03 23:02:10', '2025-06-03 23:02:10'),
('5', '1', '', '3', '1', '2025-06-03 23:02:10', '2025-06-03 23:02:10'),
('6', '1', '', '1', '1', '2025-06-03 23:02:10', '2025-06-03 23:02:10'),
('7', '1', '', '4', '1', '2025-06-03 23:02:10', '2025-06-03 23:02:10'),
('8', '1', '', '6', '1', '2025-06-03 23:02:10', '2025-06-03 23:02:10'),
('9', '1', '', '8', '1', '2025-06-03 23:02:10', '2025-06-03 23:02:10'),
('16', '2', '', '2', '1', '2025-06-03 23:02:10', '2025-06-03 23:02:10'),
('17', '2', '', '5', '1', '2025-06-03 23:02:10', '2025-06-03 23:02:10'),
('18', '2', '', '7', '1', '2025-06-03 23:02:10', '2025-06-03 23:02:10'),
('19', '2', '', '9', '1', '2025-06-03 23:02:10', '2025-06-03 23:02:10'),
('20', '2', '', '3', '1', '2025-06-03 23:02:10', '2025-06-03 23:02:10'),
('21', '2', '', '1', '1', '2025-06-03 23:02:10', '2025-06-03 23:02:10'),
('22', '2', '', '4', '1', '2025-06-03 23:02:10', '2025-06-03 23:02:10'),
('23', '2', '', '6', '1', '2025-06-03 23:02:10', '2025-06-03 23:02:10'),
('24', '2', '', '8', '1', '2025-06-03 23:02:10', '2025-06-03 23:02:10'),
('32', '1', 'clientes', '2', '1', '2025-06-03 23:10:35', '2025-06-03 23:10:35'),
('33', '1', 'cobranzas', '5', '1', '2025-06-03 23:10:35', '2025-06-03 23:10:35'),
('34', '1', 'configuracion', '7', '1', '2025-06-03 23:10:35', '2025-06-03 23:10:35'),
('35', '1', 'contabilidad', '9', '1', '2025-06-03 23:10:35', '2025-06-03 23:10:35'),
('36', '1', 'creditos', '3', '1', '2025-06-03 23:10:35', '2025-06-03 23:10:35'),
('37', '1', 'dashboard', '1', '1', '2025-06-03 23:10:35', '2025-06-03 23:10:35'),
('38', '1', 'pagos', '4', '1', '2025-06-03 23:10:35', '2025-06-03 23:10:35'),
('39', '1', 'reportes', '6', '1', '2025-06-03 23:10:35', '2025-06-03 23:10:35'),
('40', '1', 'usuarios', '8', '1', '2025-06-03 23:10:35', '2025-06-03 23:10:35'),
('47', '2', 'clientes', '2', '1', '2025-06-03 23:10:35', '2025-06-03 23:10:35'),
('48', '2', 'cobranzas', '5', '1', '2025-06-03 23:10:35', '2025-06-03 23:10:35'),
('49', '2', 'configuracion', '7', '1', '2025-06-03 23:10:35', '2025-06-03 23:10:35'),
('50', '2', 'contabilidad', '9', '1', '2025-06-03 23:10:35', '2025-06-03 23:10:35'),
('51', '2', 'creditos', '3', '1', '2025-06-03 23:10:35', '2025-06-03 23:10:35'),
('52', '2', 'dashboard', '1', '1', '2025-06-03 23:10:35', '2025-06-03 23:10:35'),
('53', '2', 'pagos', '4', '1', '2025-06-03 23:10:35', '2025-06-03 23:10:35'),
('54', '2', 'reportes', '6', '1', '2025-06-03 23:10:35', '2025-06-03 23:10:35'),
('55', '2', 'usuarios', '8', '1', '2025-06-03 23:10:35', '2025-06-03 23:10:35'),
('63', '1', 'clientes', '2', '1', '2025-06-03 23:11:04', '2025-06-03 23:11:04'),
('64', '1', 'cobranzas', '5', '1', '2025-06-03 23:11:04', '2025-06-03 23:11:04'),
('65', '1', 'configuracion', '7', '1', '2025-06-03 23:11:04', '2025-06-03 23:11:04'),
('66', '1', 'contabilidad', '9', '1', '2025-06-03 23:11:04', '2025-06-03 23:11:04'),
('67', '1', 'creditos', '3', '1', '2025-06-03 23:11:04', '2025-06-03 23:11:04'),
('68', '1', 'dashboard', '1', '1', '2025-06-03 23:11:04', '2025-06-03 23:11:04'),
('69', '1', 'pagos', '4', '1', '2025-06-03 23:11:04', '2025-06-03 23:11:04'),
('70', '1', 'reportes', '6', '1', '2025-06-03 23:11:04', '2025-06-03 23:11:04'),
('71', '1', 'usuarios', '8', '1', '2025-06-03 23:11:04', '2025-06-03 23:11:04'),
('78', '2', 'clientes', '2', '1', '2025-06-03 23:11:04', '2025-06-03 23:11:04'),
('79', '2', 'cobranzas', '5', '1', '2025-06-03 23:11:04', '2025-06-03 23:11:04'),
('80', '2', 'configuracion', '7', '1', '2025-06-03 23:11:04', '2025-06-03 23:11:04'),
('81', '2', 'contabilidad', '9', '1', '2025-06-03 23:11:04', '2025-06-03 23:11:04'),
('82', '2', 'creditos', '3', '1', '2025-06-03 23:11:04', '2025-06-03 23:11:04'),
('83', '2', 'dashboard', '1', '1', '2025-06-03 23:11:04', '2025-06-03 23:11:04'),
('84', '2', 'pagos', '4', '1', '2025-06-03 23:11:04', '2025-06-03 23:11:04'),
('85', '2', 'reportes', '6', '1', '2025-06-03 23:11:04', '2025-06-03 23:11:04'),
('86', '2', 'usuarios', '8', '1', '2025-06-03 23:11:04', '2025-06-03 23:11:04'),
('93', '4', 'clientes', '2', '1', '2025-06-03 23:11:04', '2025-06-03 23:11:04'),
('94', '4', 'cobranzas', '5', '1', '2025-06-03 23:11:04', '2025-06-03 23:11:04'),
('95', '4', 'configuracion', '7', '0', '2025-06-03 23:11:04', '2025-06-03 23:11:04'),
('96', '4', 'contabilidad', '9', '0', '2025-06-03 23:11:04', '2025-06-03 23:11:04'),
('97', '4', 'creditos', '3', '1', '2025-06-03 23:11:04', '2025-06-03 23:11:04'),
('98', '4', 'dashboard', '1', '1', '2025-06-03 23:11:04', '2025-06-03 23:11:04'),
('99', '4', 'pagos', '4', '1', '2025-06-03 23:11:04', '2025-06-03 23:11:04'),
('100', '4', 'reportes', '6', '1', '2025-06-03 23:11:04', '2025-06-03 23:11:04'),
('101', '4', 'usuarios', '8', '0', '2025-06-03 23:11:04', '2025-06-03 23:11:04'),
('108', '10', 'clientes', '2', '1', '2025-06-03 23:11:04', '2025-06-03 23:11:04'),
('109', '10', 'cobranzas', '5', '0', '2025-06-03 23:11:04', '2025-06-03 23:11:04'),
('110', '10', 'configuracion', '7', '0', '2025-06-03 23:11:04', '2025-06-03 23:11:04'),
('111', '10', 'contabilidad', '9', '0', '2025-06-03 23:11:04', '2025-06-03 23:11:04'),
('112', '10', 'creditos', '3', '0', '2025-06-03 23:11:04', '2025-06-03 23:11:04'),
('113', '10', 'dashboard', '1', '1', '2025-06-03 23:11:04', '2025-06-03 23:11:04'),
('114', '10', 'pagos', '4', '1', '2025-06-03 23:11:04', '2025-06-03 23:11:04'),
('115', '10', 'reportes', '6', '0', '2025-06-03 23:11:04', '2025-06-03 23:11:04'),
('116', '10', 'usuarios', '8', '0', '2025-06-03 23:11:04', '2025-06-03 23:11:04'),
('123', '6', 'clientes', '2', '1', '2025-06-03 23:11:04', '2025-06-03 23:11:04'),
('124', '6', 'cobranzas', '5', '1', '2025-06-03 23:11:04', '2025-06-03 23:11:04'),
('125', '6', 'configuracion', '7', '0', '2025-06-03 23:11:04', '2025-06-03 23:11:04'),
('126', '6', 'contabilidad', '9', '0', '2025-06-03 23:11:04', '2025-06-03 23:11:04'),
('127', '6', 'creditos', '3', '0', '2025-06-03 23:11:04', '2025-06-03 23:11:04'),
('128', '6', 'dashboard', '1', '1', '2025-06-03 23:11:04', '2025-06-03 23:11:04'),
('129', '6', 'pagos', '4', '0', '2025-06-03 23:11:04', '2025-06-03 23:11:04'),
('130', '6', 'reportes', '6', '0', '2025-06-03 23:11:04', '2025-06-03 23:11:04'),
('131', '6', 'usuarios', '8', '0', '2025-06-03 23:11:04', '2025-06-03 23:11:04'),
('138', '11', 'clientes', '2', '0', '2025-06-03 23:11:04', '2025-06-03 23:11:04'),
('139', '11', 'cobranzas', '5', '0', '2025-06-03 23:11:04', '2025-06-03 23:11:04'),
('140', '11', 'configuracion', '7', '0', '2025-06-03 23:11:04', '2025-06-03 23:11:04'),
('141', '11', 'contabilidad', '9', '0', '2025-06-03 23:11:04', '2025-06-03 23:11:04'),
('142', '11', 'creditos', '3', '0', '2025-06-03 23:11:04', '2025-06-03 23:11:04'),
('143', '11', 'dashboard', '1', '1', '2025-06-03 23:11:04', '2025-06-03 23:11:04'),
('144', '11', 'pagos', '4', '0', '2025-06-03 23:11:04', '2025-06-03 23:11:04'),
('145', '11', 'reportes', '6', '0', '2025-06-03 23:11:04', '2025-06-03 23:11:04'),
('146', '11', 'usuarios', '8', '0', '2025-06-03 23:11:04', '2025-06-03 23:11:04'),
('153', '1', 'clientes', '2', '1', '2025-06-03 23:11:28', '2025-06-03 23:11:28'),
('154', '1', 'cobranzas', '5', '1', '2025-06-03 23:11:28', '2025-06-03 23:11:28'),
('155', '1', 'configuracion', '7', '1', '2025-06-03 23:11:28', '2025-06-03 23:11:28'),
('156', '1', 'contabilidad', '9', '1', '2025-06-03 23:11:28', '2025-06-03 23:11:28'),
('157', '1', 'creditos', '3', '1', '2025-06-03 23:11:28', '2025-06-03 23:11:28'),
('158', '1', 'dashboard', '1', '1', '2025-06-03 23:11:28', '2025-06-03 23:11:28'),
('159', '1', 'pagos', '4', '1', '2025-06-03 23:11:28', '2025-06-03 23:11:28'),
('160', '1', 'reportes', '6', '1', '2025-06-03 23:11:28', '2025-06-03 23:11:28'),
('161', '1', 'usuarios', '8', '1', '2025-06-03 23:11:28', '2025-06-03 23:11:28'),
('168', '2', 'clientes', '2', '1', '2025-06-03 23:11:28', '2025-06-03 23:11:28'),
('169', '2', 'cobranzas', '5', '1', '2025-06-03 23:11:28', '2025-06-03 23:11:28'),
('170', '2', 'configuracion', '7', '1', '2025-06-03 23:11:28', '2025-06-03 23:11:28'),
('171', '2', 'contabilidad', '9', '1', '2025-06-03 23:11:28', '2025-06-03 23:11:28'),
('172', '2', 'creditos', '3', '1', '2025-06-03 23:11:28', '2025-06-03 23:11:28'),
('173', '2', 'dashboard', '1', '1', '2025-06-03 23:11:28', '2025-06-03 23:11:28'),
('174', '2', 'pagos', '4', '1', '2025-06-03 23:11:28', '2025-06-03 23:11:28'),
('175', '2', 'reportes', '6', '1', '2025-06-03 23:11:28', '2025-06-03 23:11:28'),
('176', '2', 'usuarios', '8', '1', '2025-06-03 23:11:28', '2025-06-03 23:11:28'),
('183', '4', 'clientes', '2', '1', '2025-06-03 23:11:28', '2025-06-03 23:11:28'),
('184', '4', 'cobranzas', '5', '1', '2025-06-03 23:11:28', '2025-06-03 23:11:28'),
('185', '4', 'configuracion', '7', '0', '2025-06-03 23:11:28', '2025-06-03 23:11:28'),
('186', '4', 'contabilidad', '9', '0', '2025-06-03 23:11:28', '2025-06-03 23:11:28'),
('187', '4', 'creditos', '3', '1', '2025-06-03 23:11:28', '2025-06-03 23:11:28'),
('188', '4', 'dashboard', '1', '1', '2025-06-03 23:11:28', '2025-06-03 23:11:28'),
('189', '4', 'pagos', '4', '1', '2025-06-03 23:11:28', '2025-06-03 23:11:28'),
('190', '4', 'reportes', '6', '1', '2025-06-03 23:11:28', '2025-06-03 23:11:28'),
('191', '4', 'usuarios', '8', '0', '2025-06-03 23:11:28', '2025-06-03 23:11:28'),
('198', '10', 'clientes', '2', '1', '2025-06-03 23:11:28', '2025-06-03 23:11:28'),
('199', '10', 'cobranzas', '5', '0', '2025-06-03 23:11:28', '2025-06-03 23:11:28'),
('200', '10', 'configuracion', '7', '0', '2025-06-03 23:11:28', '2025-06-03 23:11:28'),
('201', '10', 'contabilidad', '9', '0', '2025-06-03 23:11:28', '2025-06-03 23:11:28'),
('202', '10', 'creditos', '3', '0', '2025-06-03 23:11:28', '2025-06-03 23:11:28'),
('203', '10', 'dashboard', '1', '1', '2025-06-03 23:11:28', '2025-06-03 23:11:28'),
('204', '10', 'pagos', '4', '1', '2025-06-03 23:11:28', '2025-06-03 23:11:28'),
('205', '10', 'reportes', '6', '0', '2025-06-03 23:11:28', '2025-06-03 23:11:28'),
('206', '10', 'usuarios', '8', '0', '2025-06-03 23:11:28', '2025-06-03 23:11:28'),
('213', '6', 'clientes', '2', '1', '2025-06-03 23:11:28', '2025-06-03 23:11:28'),
('214', '6', 'cobranzas', '5', '1', '2025-06-03 23:11:28', '2025-06-03 23:11:28'),
('215', '6', 'configuracion', '7', '0', '2025-06-03 23:11:28', '2025-06-03 23:11:28'),
('216', '6', 'contabilidad', '9', '0', '2025-06-03 23:11:28', '2025-06-03 23:11:28'),
('217', '6', 'creditos', '3', '0', '2025-06-03 23:11:28', '2025-06-03 23:11:28'),
('218', '6', 'dashboard', '1', '1', '2025-06-03 23:11:28', '2025-06-03 23:11:28'),
('219', '6', 'pagos', '4', '0', '2025-06-03 23:11:28', '2025-06-03 23:11:28'),
('220', '6', 'reportes', '6', '0', '2025-06-03 23:11:28', '2025-06-03 23:11:28'),
('221', '6', 'usuarios', '8', '0', '2025-06-03 23:11:28', '2025-06-03 23:11:28'),
('228', '11', 'clientes', '2', '0', '2025-06-03 23:11:28', '2025-06-03 23:11:28'),
('229', '11', 'cobranzas', '5', '0', '2025-06-03 23:11:28', '2025-06-03 23:11:28'),
('230', '11', 'configuracion', '7', '0', '2025-06-03 23:11:28', '2025-06-03 23:11:28'),
('231', '11', 'contabilidad', '9', '0', '2025-06-03 23:11:28', '2025-06-03 23:11:28'),
('232', '11', 'creditos', '3', '0', '2025-06-03 23:11:28', '2025-06-03 23:11:28'),
('233', '11', 'dashboard', '1', '1', '2025-06-03 23:11:28', '2025-06-03 23:11:28'),
('234', '11', 'pagos', '4', '0', '2025-06-03 23:11:28', '2025-06-03 23:11:28'),
('235', '11', 'reportes', '6', '0', '2025-06-03 23:11:28', '2025-06-03 23:11:28'),
('236', '11', 'usuarios', '8', '0', '2025-06-03 23:11:28', '2025-06-03 23:11:28'),
('243', '6', 'rutas', '0', '1', '2025-06-05 00:20:06', '2025-06-05 00:20:06'),
('244', '2', 'pymes', '0', '1', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('245', '2', 'seguridad', '0', '1', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('246', '2', 'rutas', '0', '1', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('247', '2', 'caja', '0', '1', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('248', '2', 'wallet', '0', '1', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('249', '2', 'billetera', '0', '1', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('250', '2', 'garantias', '0', '1', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('251', '2', 'simulador', '0', '1', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('252', '2', 'cobranza', '0', '1', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('253', '2', 'auditoria', '0', '1', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('254', '2', 'empresa', '0', '1', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('255', '2', 'permisos', '0', '1', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('256', '2', 'preferencias', '0', '1', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('257', '2', 'reportes_cancelados', '0', '1', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('258', '2', 'reportes_desembolsos', '0', '1', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('259', '2', 'reportes_activos', '0', '1', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('260', '2', 'reportes_vencidos', '0', '1', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('261', '2', 'reportes_por_cancelar', '0', '1', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('262', '2', 'solicitudes', '0', '1', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('263', '2', 'analisis', '0', '1', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('264', '2', 'productos', '0', '1', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('265', '2', 'acuerdos', '0', '1', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('266', '2', 'cierre_mes', '0', '1', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('267', '2', 'recuperacion_desembolsos', '0', '1', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('268', '2', 'asignacion_creditos', '0', '1', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('269', '10', 'pymes', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('270', '10', 'seguridad', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('271', '10', 'rutas', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('272', '10', 'caja', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('273', '10', 'wallet', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('274', '10', 'billetera', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('275', '10', 'garantias', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('276', '10', 'simulador', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('277', '10', 'cobranza', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('278', '10', 'auditoria', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('279', '10', 'empresa', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('280', '10', 'permisos', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('281', '10', 'preferencias', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('282', '10', 'reportes_cancelados', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('283', '10', 'reportes_desembolsos', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('284', '10', 'reportes_activos', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('285', '10', 'reportes_vencidos', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('286', '10', 'reportes_por_cancelar', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('287', '10', 'solicitudes', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('288', '10', 'analisis', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('289', '10', 'productos', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('290', '10', 'acuerdos', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('291', '10', 'cierre_mes', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('292', '10', 'recuperacion_desembolsos', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('293', '10', 'asignacion_creditos', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('294', '6', 'pymes', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('295', '6', 'seguridad', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('296', '6', 'caja', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('297', '6', 'wallet', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('298', '6', 'billetera', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('299', '6', 'garantias', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('300', '6', 'simulador', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('301', '6', 'cobranza', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('302', '6', 'auditoria', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('303', '6', 'empresa', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('304', '6', 'permisos', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('305', '6', 'preferencias', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('306', '6', 'reportes_cancelados', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('307', '6', 'reportes_desembolsos', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('308', '6', 'reportes_activos', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('309', '6', 'reportes_vencidos', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('310', '6', 'reportes_por_cancelar', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('311', '6', 'solicitudes', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('312', '6', 'analisis', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('313', '6', 'productos', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('314', '6', 'acuerdos', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('315', '6', 'cierre_mes', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('316', '6', 'recuperacion_desembolsos', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('317', '6', 'asignacion_creditos', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('318', '5', 'configuracion', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('319', '5', 'clientes', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('320', '5', 'pymes', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('321', '5', 'reportes', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('322', '5', 'cobranzas', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('323', '5', 'seguridad', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('324', '5', 'rutas', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('325', '5', 'caja', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('326', '5', 'usuarios', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('327', '5', 'dashboard', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('328', '5', 'wallet', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('329', '5', 'billetera', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('330', '5', 'garantias', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('331', '5', 'simulador', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('332', '5', 'pagos', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('333', '5', 'cobranza', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('334', '5', 'contabilidad', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('335', '5', 'auditoria', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('336', '5', 'empresa', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('337', '5', 'permisos', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('338', '5', 'preferencias', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('339', '5', 'reportes_cancelados', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('340', '5', 'reportes_desembolsos', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('341', '5', 'reportes_activos', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('342', '5', 'reportes_vencidos', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('343', '5', 'reportes_por_cancelar', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('344', '5', 'solicitudes', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('345', '5', 'analisis', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('346', '5', 'productos', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('347', '5', 'acuerdos', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('348', '5', 'cierre_mes', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('349', '5', 'recuperacion_desembolsos', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('350', '5', 'asignacion_creditos', '0', '0', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('351', '1', 'pymes', '0', '1', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('352', '1', 'seguridad', '0', '1', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('353', '1', 'rutas', '0', '1', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('354', '1', 'caja', '0', '1', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('355', '1', 'wallet', '0', '1', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('356', '1', 'billetera', '0', '1', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('357', '1', 'garantias', '0', '1', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('358', '1', 'simulador', '0', '1', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('359', '1', 'cobranza', '0', '1', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('360', '1', 'auditoria', '0', '1', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('361', '1', 'empresa', '0', '1', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('362', '1', 'permisos', '0', '1', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('363', '1', 'preferencias', '0', '1', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('364', '1', 'reportes_cancelados', '0', '1', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('365', '1', 'reportes_desembolsos', '0', '1', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('366', '1', 'reportes_activos', '0', '1', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('367', '1', 'reportes_vencidos', '0', '1', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('368', '1', 'reportes_por_cancelar', '0', '1', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('369', '1', 'solicitudes', '0', '1', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('370', '1', 'analisis', '0', '1', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('371', '1', 'productos', '0', '1', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('372', '1', 'acuerdos', '0', '1', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('373', '1', 'cierre_mes', '0', '1', '2025-06-05 00:51:33', '2025-06-05 00:51:33'),
('374', '1', 'recuperacion_desembolsos', '0', '1', '2025-06-05 00:51:34', '2025-06-05 00:51:34'),
('375', '1', 'asignacion_creditos', '0', '1', '2025-06-05 00:51:34', '2025-06-05 00:51:34'),
('376', '4', 'pymes', '0', '0', '2025-06-05 00:51:34', '2025-06-05 00:51:34'),
('377', '4', 'seguridad', '0', '0', '2025-06-05 00:51:34', '2025-06-05 00:51:34'),
('378', '4', 'rutas', '0', '0', '2025-06-05 00:51:34', '2025-06-05 00:51:34'),
('379', '4', 'caja', '0', '0', '2025-06-05 00:51:34', '2025-06-05 00:51:34'),
('380', '4', 'wallet', '0', '0', '2025-06-05 00:51:34', '2025-06-05 00:51:34'),
('381', '4', 'billetera', '0', '0', '2025-06-05 00:51:34', '2025-06-05 00:51:34'),
('382', '4', 'garantias', '0', '0', '2025-06-05 00:51:34', '2025-06-05 00:51:34'),
('383', '4', 'simulador', '0', '0', '2025-06-05 00:51:34', '2025-06-05 00:51:34'),
('384', '4', 'cobranza', '0', '0', '2025-06-05 00:51:34', '2025-06-05 00:51:34'),
('385', '4', 'auditoria', '0', '0', '2025-06-05 00:51:34', '2025-06-05 00:51:34'),
('386', '4', 'empresa', '0', '0', '2025-06-05 00:51:34', '2025-06-05 00:51:34'),
('387', '4', 'permisos', '0', '0', '2025-06-05 00:51:34', '2025-06-05 00:51:34'),
('388', '4', 'preferencias', '0', '0', '2025-06-05 00:51:34', '2025-06-05 00:51:34'),
('389', '4', 'reportes_cancelados', '0', '0', '2025-06-05 00:51:34', '2025-06-05 00:51:34'),
('390', '4', 'reportes_desembolsos', '0', '0', '2025-06-05 00:51:34', '2025-06-05 00:51:34'),
('391', '4', 'reportes_activos', '0', '0', '2025-06-05 00:51:34', '2025-06-05 00:51:34'),
('392', '4', 'reportes_vencidos', '0', '0', '2025-06-05 00:51:34', '2025-06-05 00:51:34'),
('393', '4', 'reportes_por_cancelar', '0', '0', '2025-06-05 00:51:34', '2025-06-05 00:51:34'),
('394', '4', 'solicitudes', '0', '0', '2025-06-05 00:51:34', '2025-06-05 00:51:34'),
('395', '4', 'analisis', '0', '0', '2025-06-05 00:51:34', '2025-06-05 00:51:34'),
('396', '4', 'productos', '0', '0', '2025-06-05 00:51:34', '2025-06-05 00:51:34'),
('397', '4', 'acuerdos', '0', '0', '2025-06-05 00:51:34', '2025-06-05 00:51:34'),
('398', '4', 'cierre_mes', '0', '0', '2025-06-05 00:51:34', '2025-06-05 00:51:34'),
('399', '4', 'recuperacion_desembolsos', '0', '0', '2025-06-05 00:51:34', '2025-06-05 00:51:34'),
('400', '4', 'asignacion_creditos', '0', '0', '2025-06-05 00:51:34', '2025-06-05 00:51:34'),
('401', '11', 'pymes', '0', '0', '2025-06-05 00:51:34', '2025-06-05 00:51:34'),
('402', '11', 'seguridad', '0', '0', '2025-06-05 00:51:34', '2025-06-05 00:51:34'),
('403', '11', 'rutas', '0', '0', '2025-06-05 00:51:34', '2025-06-05 00:51:34'),
('404', '11', 'caja', '0', '0', '2025-06-05 00:51:34', '2025-06-05 00:51:34'),
('405', '11', 'wallet', '0', '0', '2025-06-05 00:51:34', '2025-06-05 00:51:34'),
('406', '11', 'billetera', '0', '0', '2025-06-05 00:51:34', '2025-06-05 00:51:34'),
('407', '11', 'garantias', '0', '0', '2025-06-05 00:51:34', '2025-06-05 00:51:34'),
('408', '11', 'simulador', '0', '0', '2025-06-05 00:51:34', '2025-06-05 00:51:34'),
('409', '11', 'cobranza', '0', '0', '2025-06-05 00:51:34', '2025-06-05 00:51:34'),
('410', '11', 'auditoria', '0', '0', '2025-06-05 00:51:34', '2025-06-05 00:51:34'),
('411', '11', 'empresa', '0', '0', '2025-06-05 00:51:34', '2025-06-05 00:51:34'),
('412', '11', 'permisos', '0', '0', '2025-06-05 00:51:34', '2025-06-05 00:51:34'),
('413', '11', 'preferencias', '0', '0', '2025-06-05 00:51:34', '2025-06-05 00:51:34'),
('414', '11', 'reportes_cancelados', '0', '0', '2025-06-05 00:51:34', '2025-06-05 00:51:34'),
('415', '11', 'reportes_desembolsos', '0', '0', '2025-06-05 00:51:34', '2025-06-05 00:51:34'),
('416', '11', 'reportes_activos', '0', '0', '2025-06-05 00:51:34', '2025-06-05 00:51:34'),
('417', '11', 'reportes_vencidos', '0', '0', '2025-06-05 00:51:34', '2025-06-05 00:51:34'),
('418', '11', 'reportes_por_cancelar', '0', '0', '2025-06-05 00:51:34', '2025-06-05 00:51:34'),
('419', '11', 'solicitudes', '0', '0', '2025-06-05 00:51:34', '2025-06-05 00:51:34'),
('420', '11', 'analisis', '0', '0', '2025-06-05 00:51:34', '2025-06-05 00:51:34'),
('421', '11', 'productos', '0', '0', '2025-06-05 00:51:34', '2025-06-05 00:51:34'),
('422', '11', 'acuerdos', '0', '0', '2025-06-05 00:51:34', '2025-06-05 00:51:34'),
('423', '11', 'cierre_mes', '0', '0', '2025-06-05 00:51:34', '2025-06-05 00:51:34'),
('424', '11', 'recuperacion_desembolsos', '0', '0', '2025-06-05 00:51:34', '2025-06-05 00:51:34'),
('425', '11', 'asignacion_creditos', '0', '0', '2025-06-05 00:51:34', '2025-06-05 00:51:34');

DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `slug` varchar(191) NOT NULL,
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `roles` VALUES
('1', 'Super Administrador', 'superadmin', 'Control total del sistema', '1', '2025-05-29 17:21:22', '2025-06-03 22:36:57'),
('2', 'Administrador', 'admin', 'Administrador con acceso limitado', '1', '2025-05-29 17:21:22', '2025-06-03 22:36:57'),
('4', 'Supervisor', 'supervisor', 'Supervisor de operaciones', '1', '2025-05-29 17:27:46', '2025-06-03 22:36:57'),
('5', 'Contador', 'contador', 'Encargado de contabilidad', '1', '2025-05-29 17:27:46', '2025-05-29 17:27:46'),
('6', 'Colector', 'Colector', 'Agente de cobranza', '1', '2025-05-29 17:27:46', '2025-06-03 22:36:57'),
('10', 'Caja', 'caja', 'Operador de caja', '1', '2025-06-03 22:35:21', '2025-06-03 22:36:57'),
('11', 'Cliente', 'user', 'Usuario cliente', '1', '2025-06-03 22:35:21', '2025-06-03 22:36:57');

DROP TABLE IF EXISTS `route`;
CREATE TABLE `route` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `name` text DEFAULT NULL,
  `country` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `route_credits`;
CREATE TABLE `route_credits` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `route_id` bigint(20) unsigned NOT NULL,
  `credit_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `route_credits_route_id_index` (`route_id`),
  KEY `route_credits_credit_id_index` (`credit_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `routes`;
CREATE TABLE `routes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `code` varchar(50) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `collector_id` bigint(20) unsigned DEFAULT NULL,
  `supervisor_id` bigint(20) unsigned DEFAULT NULL,
  `branch_id` bigint(20) unsigned DEFAULT NULL,
  `status` varchar(255) DEFAULT 'active',
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `zone` varchar(255) DEFAULT NULL,
  `days` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `routes_branch_id_index` (`branch_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `routes` VALUES
('1', 'RUTA  PRINCIPAL', NULL, 'Prueba de Rutas', '5', '6', '1', 'active', '1', NULL, '2025-06-03 21:30:52', '2025-06-03 21:30:52', '1', '[\"monday\",\"tuesday\",\"wednesday\",\"thursday\",\"friday\",\"saturday\"]'),
('2', 'Ruta 2', NULL, 'Pruebade zona SU', '5', '6', '2', 'active', '1', '1', '2025-06-03 21:36:04', '2025-06-04 23:42:56', 'SUR', '[\"monday\",\"tuesday\",\"wednesday\",\"thursday\",\"friday\",\"saturday\"]');

DROP TABLE IF EXISTS `summary`;
CREATE TABLE `summary` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `amount` double(8,2) DEFAULT NULL,
  `id_agent` int(11) DEFAULT NULL,
  `id_credit` int(11) DEFAULT NULL,
  `number_index` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `summary` VALUES
('1', '4', '3', '1', '1', '2021-06-27 19:55:09', NULL),
('2', '4', '3', '1', '2', '2021-06-25 19:56:13', NULL),
('3', '300', '3', '2', '1', '2021-06-27 20:01:21', NULL);

DROP TABLE IF EXISTS `system_preferences`;
CREATE TABLE `system_preferences` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `system_name` varchar(191) NOT NULL DEFAULT 'Sistema de Prestamos',
  `default_language` varchar(10) NOT NULL DEFAULT 'es',
  `default_currency` varchar(10) NOT NULL DEFAULT 'USD',
  `default_timezone` varchar(50) NOT NULL DEFAULT 'America/Mexico_City',
  `default_interest_rate` decimal(8,2) NOT NULL DEFAULT 18.00,
  `default_term` int(11) NOT NULL DEFAULT 12,
  `payment_day_grace_period` int(11) NOT NULL DEFAULT 3,
  `late_payment_fee` decimal(8,2) NOT NULL DEFAULT 5.00,
  `enable_email_notifications` tinyint(1) NOT NULL DEFAULT 1,
  `enable_sms_notifications` tinyint(1) NOT NULL DEFAULT 0,
  `days_before_payment_reminder` int(11) NOT NULL DEFAULT 3,
  `notify_on_late_payment` tinyint(1) NOT NULL DEFAULT 1,
  `notify_on_loan_approval` tinyint(1) NOT NULL DEFAULT 1,
  `session_timeout` int(11) NOT NULL DEFAULT 30,
  `enable_two_factor_auth` tinyint(1) NOT NULL DEFAULT 0,
  `log_user_actions` tinyint(1) NOT NULL DEFAULT 1,
  `password_expiry_days` int(11) NOT NULL DEFAULT 90,
  `updated_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `transactions`;
CREATE TABLE `transactions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `wallet_id` bigint(20) unsigned NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `type` enum('deposit','withdrawal','transfer_in','transfer_out','payment','commission') NOT NULL,
  `description` text DEFAULT NULL,
  `reference_id` bigint(20) unsigned DEFAULT NULL,
  `status` varchar(255) DEFAULT 'completed',
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `transactions_wallet_id_index` (`wallet_id`),
  KEY `transactions_type_index` (`type`),
  KEY `transactions_created_at_index` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `transactions` VALUES
('1', '1', '20000.00', 'deposit', 'Saldo inicial', NULL, 'completed', '1', '2025-06-03 21:44:26', '2025-06-03 21:44:26'),
('2', '2', '500000.00', 'deposit', 'Saldo inicial', NULL, 'completed', '1', '2025-06-03 21:45:09', '2025-06-03 21:45:09'),
('3', '3', '2500.00', 'deposit', 'Saldo inicial', NULL, 'completed', '1', '2025-06-03 22:17:14', '2025-06-03 22:17:14');

DROP TABLE IF EXISTS `ubicaciones`;
CREATE TABLE `ubicaciones` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `latitud` decimal(10,7) NOT NULL,
  `longitud` decimal(10,7) NOT NULL,
  `direccion` varchar(255) DEFAULT NULL,
  `ultima_actualizacion` timestamp NULL DEFAULT current_timestamp(),
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ubicaciones_user_id_foreign` (`user_id`),
  CONSTRAINT `ubicaciones_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `user_roles`;
CREATE TABLE `user_roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `role_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_roles_user_id_role_id_unique` (`user_id`,`role_id`),
  KEY `user_roles_role_id_foreign` (`role_id`),
  CONSTRAINT `user_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_roles_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `user_roles` VALUES
('1', '1', '1', '2025-06-03 22:30:50', '2025-06-03 22:30:50'),
('12', '5', '2', '2025-06-03 23:11:19', '2025-06-03 23:11:19'),
('13', '6', '4', '2025-06-03 23:11:19', '2025-06-03 23:11:19');

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `nit` varchar(100) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `province` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `phone` varchar(100) DEFAULT NULL,
  `level` varchar(255) DEFAULT 'client',
  `business_name` varchar(255) DEFAULT NULL,
  `role` varchar(255) DEFAULT 'client',
  `branch_id` bigint(20) unsigned DEFAULT NULL,
  `status` varchar(255) DEFAULT 'active',
  `lat` varchar(255) DEFAULT NULL,
  `lng` varchar(255) DEFAULT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `active_user` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `users_level_index` (`level`),
  KEY `users_status_index` (`status`),
  KEY `users_branch_id_index` (`branch_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `users` VALUES
('1', 'Administrador', NULL, 'admin@sistema.com', NULL, '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', NULL, NULL, NULL, NULL, NULL, 'admin', NULL, 'admin', NULL, 'active', NULL, NULL, NULL, NULL, '2025-06-03 18:32:52', '2025-06-03 18:32:52', NULL, '1'),
('5', 'robin', 'Ramirez', 'gueroldbenito@gmail.com', 'cobrador1', '$2y$10$GS.lzTvLUaaLAsPd9GM9NOHKRfr8KUKH61KtZ7C4aDHwV0fFHRYjm', '', '', NULL, NULL, '86595453', '1', NULL, 'colector', NULL, 'active', NULL, NULL, NULL, NULL, '2025-06-03 21:00:33', '2025-06-03 21:00:33', '', '1'),
('6', 'Hazel', 'Ramirez', 'Hazel@gmail.com', 'Supervisora1', '$2y$10$wSOM/GsP8uC84Jz9nNMmue/vOXfhWSNoszPukngOqHiH8b9kOi34u', '', '', NULL, NULL, '90876543', '1', NULL, 'supervisor', NULL, 'active', NULL, NULL, NULL, NULL, '2025-06-03 21:01:33', '2025-06-03 21:01:33', '', '1');

DROP TABLE IF EXISTS `users_has_route`;
CREATE TABLE `users_has_route` (
  `route_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `agent_has_supervisor_id` int(11) NOT NULL,
  PRIMARY KEY (`route_id`),
  KEY `fk_users_has_route_agent_has_supervisor1_idx` (`agent_has_supervisor_id`),
  KEY `fk_users_has_route_route1_idx` (`route_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `wallet`;
CREATE TABLE `wallet` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `country` int(11) DEFAULT NULL,
  `address` varchar(191) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wallet` VALUES
('1', 'Caja principal', NULL, '1', 'Madrid', NULL),
('2', 'madrid', '2021-06-24 17:51:19', '1', 'MADRID', NULL);

DROP TABLE IF EXISTS `wallets`;
CREATE TABLE `wallets` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `supervisor_id` bigint(20) unsigned DEFAULT NULL,
  `balance` decimal(10,2) DEFAULT 0.00,
  `description` varchar(255) DEFAULT NULL,
  `wallet_type` varchar(255) DEFAULT 'agent',
  `status` varchar(255) DEFAULT 'active',
  `country_id` bigint(20) unsigned DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `legacy_id` int(11) DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `wallets_user_id_foreign` (`user_id`),
  KEY `wallets_supervisor_id_foreign` (`supervisor_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wallets` VALUES
('1', '1', NULL, '20000.00', 'Primer billatera desde el sitio de soporte', 'agent', 'active', NULL, NULL, NULL, '1', NULL, '2025-06-03 21:44:26', '2025-06-03 21:44:26'),
('2', '5', NULL, '500000.00', 'PRueba dos', 'agent', 'active', NULL, NULL, NULL, '1', NULL, '2025-06-03 21:45:09', '2025-06-03 21:45:09'),
('3', '6', NULL, '2500.00', 'Nueva Billeteta', 'agent', 'active', NULL, NULL, NULL, '1', NULL, '2025-06-03 22:17:14', '2025-06-03 22:17:14');

